import { redirect } from "next/navigation";

export default function Page() {
    redirect('/en/opportunities');
}
